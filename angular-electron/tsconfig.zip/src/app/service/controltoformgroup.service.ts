import { BasicControl } from "../model/basiccontrol";
import { Injectable } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";

@Injectable()
export class ControlToFormGroupService {
  constructor() { }

  toFormGroup(basiccontrols: BasicControl<any>[] ) {
    let group: any = {};

    basiccontrols.forEach( control=> {
      group[control.key] = control.required ? new FormControl(control.value || '', Validators.required)
                                              : new FormControl(control.value || '');
    });
    return new FormGroup(group);
  }
}