import { BasicControl } from './basiccontrol';

export class TextboxControl extends BasicControl<string> {
  controlType = 'textbox';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}